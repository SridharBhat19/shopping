﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DataAccessLayer.Models
{
    public partial class Product1
    {
        public int Pid { get; set; }
        public string Pname { get; set; }
        public decimal? Price { get; set; }
    }
}
