﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DataAccessLayer.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Orders = new HashSet<Order>();
        }

        public long Mobno { get; set; }
        public string Custname { get; set; }
        public string Loc { get; set; }
        public string Addr { get; set; }
        public string Pass { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
