﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DataAccessLayer.Models
{
    public partial class Order
    {
        public int Oid { get; set; }
        public int? Prid { get; set; }
        public long? Cuid { get; set; }
        public decimal? Qty { get; set; }
        public decimal? Totalamt { get; set; }

        public virtual Customer Cu { get; set; }
        public virtual Product Pr { get; set; }
    }
}
