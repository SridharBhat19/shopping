﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace DataAccessLayer.Models
{
    public partial class projectDBContext : DbContext
    {
        public projectDBContext()
        {
        }

        public projectDBContext(DbContextOptions<projectDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Product1> Products1 { get; set; }

       /* protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("server=(localdb)\\MSSqlLocalDB;Database=projectDB;Trusted_Connection=true;");
            }
        }*/

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.Mobno)
                    .HasName("PK__Customer__0CE2D360ADEAC77C");

                entity.ToTable("Customer");

                entity.Property(e => e.Mobno)
                    .ValueGeneratedNever()
                    .HasColumnName("mobno");

                entity.Property(e => e.Addr)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("addr");

                entity.Property(e => e.Custname)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("custname");

                entity.Property(e => e.Loc)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("loc");

                entity.Property(e => e.Pass)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pass");
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.HasKey(e => e.Oid)
                    .HasName("PK__Orders__C2FFCF13408D2281");

                entity.Property(e => e.Oid).HasColumnName("oid");

                entity.Property(e => e.Cuid).HasColumnName("cuid");

                entity.Property(e => e.Prid).HasColumnName("prid");

                entity.Property(e => e.Qty)
                    .HasColumnType("money")
                    .HasColumnName("qty");

                entity.Property(e => e.Totalamt)
                    .HasColumnType("money")
                    .HasColumnName("totalamt");

                entity.HasOne(d => d.Cu)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.Cuid)
                    .HasConstraintName("FK__Orders__cuid__31EC6D26");

                entity.HasOne(d => d.Pr)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.Prid)
                    .HasConstraintName("FK__Orders__prid__30F848ED");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__Product__DD37D91AB31279E2");

                entity.ToTable("Product");

                entity.Property(e => e.Pid)
                    .ValueGeneratedNever()
                    .HasColumnName("pid");

                entity.Property(e => e.Pname)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("pname");

                entity.Property(e => e.Price).HasColumnName("price");
            });

            modelBuilder.Entity<Product1>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__Products__DD37D91AB537F381");

                entity.ToTable("Products");

                entity.Property(e => e.Pid).HasColumnName("pid");

                entity.Property(e => e.Pname)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("pname");

                entity.Property(e => e.Price)
                    .HasColumnType("money")
                    .HasColumnName("price");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
