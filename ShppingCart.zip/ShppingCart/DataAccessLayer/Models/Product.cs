﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DataAccessLayer.Models
{
    public partial class Product
    {
        public Product()
        {
            Orders = new HashSet<Order>();
        }

        public int Pid { get; set; }
        public string Pname { get; set; }
        public double? Price { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
