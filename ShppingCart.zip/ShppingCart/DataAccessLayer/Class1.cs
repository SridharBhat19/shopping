﻿using System;
using System.Collections.Generic;
using System.Linq;
using EntityLayer;
using DataAccessLayer.Models;

namespace DataAccessLayer
{
    public class ProjectDBDAL
    {
        projectDBContext db;
        public ProjectDBDAL(projectDBContext db)
        {
            this.db = db;
        }
        public bool Login(long mobno, string pwd)
        {
            try
            {
                var result = db.Customers.Where(x => x.Mobno == mobno && x.Pass == pwd).SingleOrDefault();
                if (result == null)
                    throw new Exception("Invalid Credentials");
                else
                    return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool InsertCustomer(CustomerEntity ce)
        {
            try
            {
                Customer c = new Customer();
                c.Mobno = ce.mobno;
                c.Custname = ce.custname;
                c.Loc = ce.loc;
                c.Addr = ce.addr;
                c.Pass = ce.pass;
                db.Customers.Add(c);
                var res = db.SaveChanges();
                if (res > 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                throw;
            }
        }
        public bool InsertProduct(ProductEntity pe)
        {
            try
            {
                Product1 p = new Product1();
                p.Pid = pe.pid;
                p.Pname = pe.pname;
                p.Price = pe.price;
                db.Products1.Add(p);
                var res = db.SaveChanges();
                if (res > 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                throw;
            }
        }
        public bool InsertOrder(OrderEntity oe)
        {

            try
            {
                Order oi = new Order();
                oi.Oid = oe.oid;
                oi.Prid= oe.prid;
                oi.Cuid = oe.cuid;
                oi.Qty = oe.qty;
                var totamt = db.Products.Where(x => x.Pid == oi.Prid).SingleOrDefault();
                oi.Totalamt = (decimal)totamt.Price * oi.Qty;
                db.Orders.Add(oi);
                var res = db.SaveChanges();
                if (res > 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                throw;
            }




        }
        public bool DeleteProduct(int pid)
        {
            try
            {
                var res = db.Products1.Where(x => x.Pid == pid).SingleOrDefault();
                if (res == null)
                    throw new Exception("Invalid Product ID");
                else
                {
                    db.Products1.Remove(res);
                    var r = db.SaveChanges();
                    if (r > 0)
                        return true;
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
        public bool CancelOrder(int cid)
        {
            try
            {

                var res1 = db.Orders.Where(x => x.Oid == cid).SingleOrDefault();
                if (res1 == null)
                {
                    throw new Exception("Invalid Order ID");
                }

                else
                {
                    db.Orders.Remove(res1);
                    var r = db.SaveChanges();
                    if (r > 0)
                        return true;
                }
                return false;

            }
            catch
            {
                throw;
            }
        }
        public bool DeleteCustomer(long mobno)
        {
            try
            {
                var res2 = db.Customers.Where(x => x.Mobno == mobno).SingleOrDefault();
                if (res2 == null)
                {
                    throw new Exception("Invalid Order ID");
                }

                else
                {
                    db.Customers.Remove(res2);
                    var r = db.SaveChanges();
                    if (r > 0)
                        return true;
                }
                return false;
            }
            catch
            {
                throw;
            }
        }

        //report by retrieving data fom multile tables
        public List<CustomModel>GetOrderDetails(long CustMobNo)
        {
            List<CustomModel> model = new List<CustomModel>();
            try
            {
                var data = (from c in db.Customers
                            join o in db.Orders
                            on c.Mobno equals o.Cuid
                            join p in db.Products1
                            on o.Prid equals p.Pid
                            where c.Mobno == CustMobNo
                            select new CustomModel
                            {
                                CustMobNo = c.Mobno,
                                CustName = c.Custname,
                                ProdName = p.Pname,
                                OrderId = o.Oid,
                                Qty = o.Qty,
                                TotAmt = o.Totalamt
                            }).ToList();
                return data;
            }
            catch
            {
                throw;
            }
            
        }
    }
}
