﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataAccessLayer.Models;
using DataAccessLayer;
using Microsoft.AspNetCore.Cors;
using EntityLayer;

namespace ShoppingCartRESTAPIService.Controllers
{
    [Route("api/ShoppingCart")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class ShoppingCartController : ControllerBase
    {
        projectDBContext db=null;
        ProjectDBDAL dal;
        public ShoppingCartController()
        {
            dal = new ProjectDBDAL(db);
        }
        [HttpPost]
        [Route("InsertProduct")]
        public bool PostProduct(ProductEntity pe)
        {
            return dal.InsertProduct(pe);
        }

        [HttpPost]
        [Route("GetCustomerOrder/{mobno}")]
        public List<CustomModel>GetCustmoerModel(long mobno)
        {
            return dal.GetOrderDetails(mobno);
        }

       [HttpDelete]
       [Route("DeleteCustomer")]
       public bool DeleteCustomer(long mobno)
        {
            return dal.DeleteCustomer(mobno);
        }

        [HttpDelete]
        [Route("CancelOrder")]
        public bool CancelOrder(int cid)
        {
            return dal.CancelOrder(cid);
        }

        [HttpDelete]
        [Route("DeleteProduct")]
        public bool DeleteProduct(int pid)
        {
            return dal.DeleteProduct(pid);
        }

        [HttpPost]
        [Route("PostCustomer")]
        public bool PostCustomer(CustomerEntity ce)
        {
            return dal.InsertCustomer(ce);
        }
        [HttpPost]
        [Route("PostOrders")]
        public bool PostOrders(OrderEntity oe)
        {
            return dal.InsertOrder(oe);
        }
    }
}
