﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityLayer
{
    public class ProductEntity
    {
        public int pid { get; set; }
        public string pname { get; set; }
        public decimal price { get; set; }
    }
}

