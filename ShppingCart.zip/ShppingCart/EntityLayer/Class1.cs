﻿using System;

namespace EntityLayer
{
    public class CustomerEntity
    {
        public long mobno { get; set; }

        public string custname { get; set; }
        public string loc { get; set; }
        public string addr { get; set; }
        public string pass { get; set; }
    }
}
