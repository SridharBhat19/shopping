﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityLayer
{
    public class OrderEntity
    {
        public int oid { get; set; }

        public int prid { get; set; }
        public int cuid { get; set; }
        public decimal qty { get; set; }
        public decimal toalamt { get; set; }
    }
}
