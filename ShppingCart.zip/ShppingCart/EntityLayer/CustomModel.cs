﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityLayer
{
    public class CustomModel
    {
        public string CustName { get; set; }
        public long CustMobNo { get; set; }
        public string ProdName { get; set; }
        public int OrderId { get; set; }
        public decimal? Qty { get; set; }
        public decimal ? TotAmt { get; set; }
    }
}
